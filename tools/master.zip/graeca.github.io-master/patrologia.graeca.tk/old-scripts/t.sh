#!/bin/sh
echo "Content-type: text/html"
echo ''
 ls
 echo "fdfdfdfd"
