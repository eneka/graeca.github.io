#!/bin/sh
clearDOC(){
newfile=$1

#file=./ale.txt

pattern1="^[0-9].*$" 
substitute1=""
#newfile=`cat $newfile`
 
#newfile=`sed '/Ερευνητικό /,/προέλευσής του./c\---' "$file"`
 
  
newfile=` echo "$newfile" | sed '/Ερευνητικό /,/προέλευσής του./c\ ---'`
 
 
newfile=`echo "$newfile"  | sed  -r -e 's/'"$pattern1"'/'$substitute1'/g'`
echo "$newfile"
}


putCOLOR(){

#newcolorresults=`putcolor "a1+a2" "$results"`
string=$1
results=$2
#	echo $string
IFS='+'
s="("
count=0
for i in `echo "$string"`
  do

  if [ $count -eq 0 ]
  then
  s=$s$i
  else
  s=$s"|"$i
  fi
  count=`expr $count + 1`
  done	
  s=$s")"
 
  
  
  #echo "$s"> ./searchitemFILE
  #s=`sh monotoniko.sh searchitemFILE`
  #echo $s
  
  
  newresults=`echo "$results" | sed -r 's/'$s'/<span id=wordcolor>&<\/span>/g'`
  echo "$newresults"
  
}

splitRes(){
echo "Content-type: text/html"
echo ''



IFS=$2
results=$1
 
res=""
countfiles=0
countlines=0
 
#echo "$results"
#for line in `seq 1 100`
#for line in `echo "$results"`
for line in `echo "$results"`
do
#IFS=$2
#echo "$line"
countlines=`expr $countlines + 1`
 
res="$res""$line""$IFS"
#echo $res

if [ "$countlines" = "3" ]
then
countfiles=`expr $countfiles + 1`
echo "" > "./split/""file""$countfiles"
echo "$res" >> "./split/""file""$countfiles"
#echo "$res$IFS"
res=""
echo "file""$countfiles"
countlines=0
#echo "============="
	#if [ "$countfiles" = "1" ]
	#then
	#cat "./split/""file""$countfiles"
	#echo "next"
	#fi


fi
done

countfiles=`expr $countfiles + 1`
echo "" > "./split/""file""$countfiles"
echo "$res" >> "./split/""file""$countfiles"
echo "file""$countfiles"
}
main(){

IFS="
"
results="a1  a2 a3 a4\na5 a6 a7 \na8 a9\n a10\n a11"


echo "-----------------------"
newcolorresults=`putCOLOR "a1" "$results"`
#echo "$newcolorresults"
echo "=============="



#splitRes "$results" "$IFS"

#clearDOC ./ale.txt
sedEx
}




sedEx(){
	
#sed -n 1112,21113p ale.txt
#exit
#sed = ale.txt

#sed /1/i\ssss ale.txt |sed /1/a\ssss #start, end of line
echo "aaaa ssss\n ffff\n33333f" |sed -n 1,3p 
}
main

