#!/bin/sh


createSearchBlock(){
#<input type="text" name="xsearchitems" value="">
cat << EOF > searchForm
	
<head><meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />
<script src=jquery213.js></script><script src=tooltip.js></script>
<link rel=stylesheet type=text/css href=tooltip.css>
</head>
	
<div id='title'>
<h1>Migne Patrologia Graeca</h1>
</div>

<div id='formdiv'>


<form id='myform'  action="front.sh">

Search (only Greek):
<input  id="input" style="height:50px;font-size:12pt;"  type="text" name="searchitems" value="">

EOF

echo "<select id='select' style='height:50px;font-size:12pt' name="book">" >> searchForm
#echo "<option  value="All">All</option>" >> searchForm
#for i in `ls`
IFS='
'
for  i in `ls  -d ./db/*/ | grep -v 'extras'`
do
echo "<option  value='""$i""'>$i</option>" >> searchForm
done
echo "</select>" >> searchForm		
		#script for drag chars
cat << EOF >> searchForm	
<input id='submit' type="submit" value="Go!" style="height:50px;font-size:12pt;">
<img id='keyboardimg' src="key.png" alt="key.png" >
</form>
</div> 

EOF

}


writeSearchBlock(){
	file=$1
	IFS='
	'
for i in `cat "$file"`
do
# echo "<br>"
 echo $i
#echo "i"
done
	
}


writeCharsBlock(){

echo '<div class="keyboard">'

echo "<h3>"	

IFS=" "
count=0

for char in `cat alfabet`
do
#############echo "<span style='background-color:#E6E6FA;padding: 5px 5px 5px 5px' ondragstart='dragStart(event)' draggable='true' id='char"$count"'>"
echo '<span class="char" >'

############echo "<span draggable="true" style='background-color:#E6E6FA;padding: 5px 5px 5px 5px'>"
count=`expr $count + 1`
echo $char
echo "</span>"

done

echo "</h3>"
echo '</div>'

IFS='
'

}

main(){
	#file=./db/aaa/aaa.txt
	#pattern="σθε"
	#t=`formattextofFile "$file" "$pattern"`
	#echo "$t"

#exit


#############################

echo "Content-type: text/html"
echo ''



createSearchBlock

writeSearchBlock searchForm
#echo "i"
#exit
writeCharsBlock
hexstring="$QUERY_STRING"






results=`sh engine.sh $hexstring | sed  -r 's/^.*$/'"<div>\["'&'"\]<\/div>"'/g'| sed  -r ':a;N;$!ba;s/\n/\n<br>/g'`
numlines=`echo "$results"|wc -l`
#echo "$results"
#echo $numlines
if [ "$numlines" = "1" ] #is 1 because the dir without value is printed from engine.sh
				then
				
					
				return
				else
				:
			    echo "$results" |sed -n 1,"$numlines"p 
				fi








}


main
