$(document).ready(function() {
	//alert ("lll");
	$('.keyboard').hide();
	$('#formdiv').click(function(){
  //  alert("The paragraph was clicked.");
    //alert($(this).val());
});
    
    
    	$('.char').click(function(){
  // alert("The paragraph was clicked.");
  //  alert( $(this).text());
$('#input').val($('#input').val()+$(this).text());
});
    
   
    
    $('#keyboardimg').click(function(){
  // alert("The paragraph was clicked.");
   $('.keyboard').toggle();

});
        //http://infoheap.com/jquery-ajax-load/
  
  //  <div id="result" style="background-color:lightgray"></div>

 //<script type="text/javascript">
 //$("#result").load("/api/get-dump.php?param1=val1");
 //</script> 
    
 
    
    
    
    //Get
var bla = $('#txt_name').val();

//Set

		
	
	
});
