#!/bin/sh
echo "Content-type: text/html"
echo ''
echo 'frfr'
#ls ./data/*/*
ls -d */
echo 'frfr'
IFS='
'
for dir in `ls -d ./data/*`
do

#echo "kkk" >./db/fffff/rrr
#echo "<a href="$file">$file</a>"
#findLinesperFile $file $searchitem


bdir=`basename "$dir"`
#echo "$bdir"

for file in `ls  "$dir"/*`
do
count=`expr $count + 1`
bfile=`basename "$file"`
#echo ./db/"$bdir"
#echo "$file" ./db/"$bdir/$bfile"

mkdir -p ./db/"$bdir" 
cp ./data/"$bdir/$bfile" ./db/"$bdir"
done

done 







for file in `ls -d ./db/*/*`
do
echo "$file" 


count=0
for line in `cat "$file" | sed  -r 's/^.*$/'"|"'&/g'`
do
count=`expr $count + 1`

echo $count$line 
#>>./db/$f".db"

done


done
exit

#echo "index*text" > ./db/$f".db"




