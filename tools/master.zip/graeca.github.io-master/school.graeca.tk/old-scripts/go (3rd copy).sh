#!/bin/sh
#http://code-maven.com/set-up-cgi-with-apache
#http://httpd.apache.org/docs/current/howto/cgi.html
#sudo a2enmod rewrite   

#cd /etc/apache2/mods-enabled

#sudo ln -s ../mods-available/cgi.load

#sudo service apache2 restart  

#sudo gedit /etc/apache2/apache2.conf

#sudo gedit /etc/apache2/sites-available/000-default.conf

#sudo gedit /etc/apache2/conf-available/serve-cgi-bin.conf

#chmod -R  0777 hta

#ln -s /etc

#chmod -R 777 /etc/apache2/apache2.conf






select(){
	#select field1 from file where field2 like text
	file=$3
	resultfield=$1
	wherefield=$5
	#echo $resultfield	
	#echo $wherefield
	
	numresultfield=`fNameTofNumber $file  $resultfield`
	numwherefield=`fNameTofNumber $file  $wherefield`
	
	#echo "----"
	#echo $numresultfield	
	#echo $numwherefield
	#echo "-----"
	
	
	
	fieldEX=`expr $numwherefield - 1`
	
	operator=$6
	text=$7
	#echo "----rrrrrrrr"
 	#echo $text
 	
 	#lines=`cat $file | sed  -n -r '/^(([^|]*)(\|)){'$fieldEX','$fieldEX'}([^|]*)'$text'/p' `
 	#echo "$lines"
	#return
	
 	
 	
case $operator in
   "like" )
	 lines=`cat $file | sed  -n -r '/^(([^|]*)(\|)){'$fieldEX','$fieldEX'}([^|]*)'$text'/p' `
	;;
	"equal")
	 lines=`cat $file | sed  -n -r '/^(([^|]*)(\|)){'$fieldEX','$fieldEX'}'$text'(\||$)/p'`
	;;
	*);;
	esac
	#resultfield="*"
	

	
	
	
	
	case $resultfield in
   "*" )
	echo "$lines"
	return
	;;
	*);;
	esac
	
	
	
	
IFS='
'

for line in `echo "$lines"`
do

count=0
IFS='|'

	for wherefield in  $line
	do
	count=`expr $count + 1`
		if [ "$count" = "$numresultfield" ]
		then

		echo $wherefield

		fi

	done


#fi
#echo $line
done

#echo $count
 }
 

fNameTofNumber(){
file=./db/data/insert
file=$1
field=$2
#header=`cat $file | sed  -n -r '/(.*\*)/p'`	 
header=`cat $file | sed  -n -r '/^(.*\*){1,100}/p'`	 
OLDIFS=$IFS
IFS='*'
#echo "$header"

count=0
for tablefield in $header
do
count=`expr $count + 1`
#echo "==="
#echo $tablefield

#echo $field
#echo $count
#echo "==="
if [ "$field" = "$tablefield" ]
then
#echo "----------"
numfield=$count
echo $numfield
#echo $tablefield
#echo "----------"

fi



done

IFS=$OLDIFS

#exit
 }


writeSearchBlock(){
	file=$1
for i in `cat "$file"`
do
# echo "<br>"
 echo $i
:
done
	
}
writeAuthorBlock(){
IFS='
'
echo '<div id=listing style="background-color:#eae8d4;padding: 5px 5px 5px 5px">'
#for  file in `ls ./data/*/*.txt`
echo "CATALOG""<br>"

#for  file in `ls  ./data/*/* | grep -v 'extras'`
for  file in `ls  -d ./db/*/ | grep -v 'extras'`
do
#echo $file
 
#file=`echo $file | sed -r 's/\s/\\\ /g'`
echo "<a href="$file">$file</a>""---"
#cat $file
:
done

echo "</div>"
						 #ls  ./data/*/* | grep -v 'extras'

							#ls  /etc/*/* 
#exit
}

createSearchBlock(){
#<input type="text" name="xsearchitems" value="">
cat << EOF > searchForm
	
<head><meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />
<script src=jquery213.js></script><script src=tooltip.js></script>
<link rel=stylesheet type=text/css href=tooltip.css>
</head>
	
<div id='title'>
<h1>Migne Patrologia Graeca</h1>
</div>

<div id='mainframe'>


<form id='myform'  action="go.sh">

Search (only Greek):
<input  id="input" style="height:50px;font-size:12pt;"  type="text" name="searchitems" value="">

EOF

echo "<select id='select' style='height:50px;font-size:12pt' name="book">" >> searchForm
#echo "<option  value="All">All</option>" >> searchForm
#for i in `ls`
IFS='
'
for  i in `ls  -d ./db/*/ | grep -v 'extras'`
do
echo "<option  value='""$i""'>$i</option>" >> searchForm
done
echo "</select>" >> searchForm		
		#script for drag chars
cat << EOF >> searchForm	
<input id='submit' type="submit" value="Go!" style="height:50px;font-size:12pt;">
<img id='imgkey' src="key.png" alt="key.png" >
</form>
</div> 

EOF






}

findLinesperFile(){
	
filedb="sssdb"
filedb=$1

#index=2
searchtext=nicedaycccc
searchtext=$2
#echo $searchitem
#echo $searchtext
#text=$(select "text" from $filedb where "index" like $index)
#####text=$(select "text" from $filedb where "text" like $searchtext)
text=$(select "*" from $filedb where "text" like "$searchtext")






IFS='
'

for i in `echo "$text"`

do
 echo "<br>"
 echo $i
:
done
	
	
	
	
}



decodeQueryString(){
	
	QUERY_STRING=$1
	#E1BC80CEBD
	
	
	
	#
	
	
	#return
	
	#echo $QUERY_STRING
	#echo $book
				#book=`echo "$QUERY_STRING" | cut -d'&' -f2`
	 
	itemsWords=`echo "$QUERY_STRING" | cut -d'&' -f1`
	items=`echo "$itemsWords" | cut -d'=' -f2`
	#echo $items
	IFS='+'
	
	
	
	for item in $items
	do
	
	
			#item=`echo "$item" | sed 's/%//g'`
	#item=``
	echo -n "$item" | sed 's/%\([0-9A-F]\{2\}\)/\\\\\\x\1/gI' | xargs printf
	echo '\n'
	done
	
	
	
	
	
}


writeCharsBlock(){

echo '<div class="keyboard">'
echo "<h3>"	
IFS=" "
count=0
for char in `cat alfabet`
do
#echo "<span style='background-color:#E6E6FA;padding: 5px 5px 5px 5px' ondragstart='dragStart(event)' draggable='true' id='char"$count"'>"
echo '<span class="char" >'
#echo "<span draggable="true" style='background-color:#E6E6FA;padding: 5px 5px 5px 5px'>"
count=`expr $count + 1`
echo $char
echo "</span>"

done
echo "</h3>"
	echo '</div>'
}



createSearchPattern(){
IFS='
'


for i in `decodeQueryString $QUERY_STRING`
  do



  s=$s"[^|]*"$i
  
  done	
  s=$s"[^|]*"
   echo $s
}
createSearchPattern0ld(){

for i in `decodeQueryString $QUERY_STRING`
  do
  
  
  s=$s"[^|]*"$i
  
  done	
  s=$s"[^|]*"
  echo $s
}

convertFilestoDB(){
 
for file in `ls ./data/*`
do
count=0
#echo "<a href="$file">$file</a>"
#findLinesperFile $file $searchitem

IFS='
'
f=`basename $file`
echo "index*text" > ./db/$f".db"
for line in `cat $file | sed -r 's/^.*$/'"|"'&/g'`
do
count=`expr $count + 1`

echo $count$line >>./db/$f".db"

done

done 

}



main(){
	
#echo -n 5a | sed 's/\([0-9A-F]\{2\}\)/\\\\\\x\1/gI' | xargs printf
#echo 'charset: UTF-8'
#decodeQueryString $QUERY_STRING
#return
#t=`decodeQueryString $QUERY_STRING`
#echo $t
#createSearchPattern
#return
#echo -n E1BC80CEBD | sed 's/\([0-9A-F]\{2\}\)/\\\\\\x\1/gI' | xargs printf
#uenc='H%C3%B6he %C3%BCber%20dem%20Meeresspiegel%E1%BC%80%CE%BD%E1%BD%B9%CE%BD%CE%B7%CF%84%E1%BD%B9%CE%BD'
#utf8=$(echo -e "${uenc//%/\\x}")
#echo $utf8
#echo   \x5a
# | xargs echo -e
#echo $QUERY_STRING
#findLinesperFile "sssdb" "nicedaycccc"
#searchitem="ni.*11"



#convertFilestoDB

#return

 
echo "Content-type: text/html"
echo ''
#echo "$QUERY_STRING"


#echo -n "%CE%BD%CF%84aaaa%CE%BD%CF%84" | sed 's/%\([0-9A-F]\{2\}\)/\\\\\\x\1/gI' | xargs printf


createSearchBlock
writeSearchBlock searchForm
				writeCharsBlock
				#writeAuthorBlock


searchitem=`createSearchPattern`

############################################
#Check if quesry sting has nothing to search
############################################
if [ "$searchitem" = "[^|]*" ]
	then
				#echo "Please write something, better with 2 words for faster execution"
	:
	exit
	else
	#echo $searchitem
	:
fi
############################################

echo "<br>"

#############################
#Create Div of search results
#############################
#echo '<div id=listing style="background-color:#fff7a4;padding: 5px 5px 5px 5px">'
echo '<div id=listing style="background-color:white;padding: 5px 5px 5px 5px">'
#echo '<br>==================================================================<br>'



#############################
#Decode Book Selected
#############################
#echo "$QUERY_STRING"

book=`echo "$QUERY_STRING" | cut -d'&' -f2`
book=`echo "$book" | cut -d'=' -f2`
book=`echo -n "$book" | sed 's/%\([0-9A-F]\{2\}\)/\\\\\\\x\1/gI' | xargs printf` #has one more '/' because of echo
#book=$book'\n'
#echo "Searching in ""$book"
book=`echo -n "$book"| sed 's/+/ /g'`
#echo '<br>=================================================================='
#############################
echo "Searching in ""$book"

#############################
#Check if All books selected
#############################
if [ "$book" == "All" ]
then
echo "Please Choose Something Specific for faster execution"
exit
else
:
fi
#############################


IFS='
'

for file in `ls $book* | grep -v extras`
#for file in `ls ./db/*/* | grep -v extras`
do
#echo $searchitem
resLINES=`findLinesperFile $file "$searchitem"`

#echo "llllll:"
#echo "$resLINES"
#exit



#t=`cat $file`

#resLINES=`echo "$t" | sed -r 's/'"$searchitem"'/&/g'`

######################
#Check for empty lines
######################
if [ -z "$resLINES" ]

then
:#null string

else
#echo "<br>"$file
echo "<br>"
echo "go to ""<a href='"$file"'>$file</a>"
				#echo "$resLINES"
#----------
#return
IFS='
'
for line in `echo "$resLINES"`
do
	IFS='|'
	count=0
	for field in  $line
	do
	count=`expr $count + 1`
	if [ "$count" -eq "1" ]
		then
		echo "<b>"$field"</b>"
	fi
	if [ "$count" -eq "2" ]
		then
		echo "|   "$field
		
	echo '<a href=http://127.0.0.1/hta/go.sh?searchitems=%CF%86%CF%81%CE%BF%CE%BD%CF%84&book=.%2Fdb%2Faaa%2F>Go!</a>	'
	fi
		
	done
done





#--------------
echo "<br>"
fi







done 
######################


echo '</div>'
#############################

return


}
 


main


