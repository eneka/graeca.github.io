#!/bin/sh
 






monotoniko(){
	#text=`cat "$file"| sed  -r ':a;N;$!ba;s/\n//g'`
file="./grammata"
text=`cat "$file"`
text=$1
pattern1="(ἵ|ι|ἱ|ί|ὶ|ἱ|ῖ|ἰ|ἶ|ἴ|ἷ|ϊ|᾿Ι|῾Ι)"
pattern2="(ῆ|ἡ|η|ὴ|ή|ῇ|ἠ|ἦ|ἥ|ἤ|῾Η)"
pattern3="(ὓ|ῦ|υ|ὕ|ὺ|ὐ|ύ|ὑ|ὔ|ὗ|ὖ|᾿Υ)"
pattern4="(ἐ|ἕ|έ|ε|ἔ|ὲ|ἑ|᾿Ε|῾Ε)"
pattern5="(ό|ο|ὁ|ὸ|ὅ|ὀ|ὄ|ὀ|᾿Ο)"
pattern6="(Ἀ|ά|α|ὰ|ἀ|ἁ|ἄ|ἅ|ᾷ|ᾶ|᾿Α|῾Α)"
pattern7="(ῶ|Ὠ|ω|ῷ|ᾧ|ὡ|ώ|ὧ|ὤ|ὠ|ὥ|᾿Ω)"


#text=`echo "$text"| sed  -r  's/'"$pattern1"'/ι/g'| sed  -r  's/'"$pattern2"'/ι/g'`
text=`echo "$text"| sed  -r -e 's/'"$pattern1"'/ι/g' -e  's/'"$pattern2"'/η/g' -e  's/'"$pattern3"'/υ/g' -e  's/'"$pattern4"'/ε/g' -e  's/'"$pattern5"'/ο/g' -e  's/'"$pattern6"'/α/g' -e  's/'"$pattern7"'/ω/g'`
echo "$text" 
}

file="./grammata"
searchitem=`cat "$file"`
#echo "$searchitem"
searchitem=`monotoniko "$searchitem"`
echo "$searchitem" 

#t="ls"
#eval $t





 




